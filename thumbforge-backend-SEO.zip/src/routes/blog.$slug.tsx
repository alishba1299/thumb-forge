import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { seo, jsonLd, breadcrumbSchema, SITE_URL, DEFAULT_OG_IMAGE } from "@/lib/seo";
import { PageShell } from "@/components/site/PageShell";
import { posts } from "@/lib/posts";
import { ArrowLeft } from "lucide-react";

export const Route = createFileRoute("/blog/$slug")({
  loader: ({ params }) => {
    const post = posts.find((p) => p.slug === params.slug);
    if (!post) throw notFound();
    return post;
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Post not found" }, { name: "robots", content: "noindex" }] };
    const path = `/blog/${loaderData.slug}`;
    const iso = new Date(loaderData.date).toISOString();
    return {
      ...seo({ title: `${loaderData.title} | ThumbForge Blog`, description: loaderData.description, path, type: "article" }),
      scripts: [
        jsonLd({
          "@context": "https://schema.org",
          "@type": "Article",
          headline: loaderData.title,
          description: loaderData.description,
          datePublished: iso,
          dateModified: iso,
          image: DEFAULT_OG_IMAGE,
          mainEntityOfPage: `${SITE_URL}${path}`,
          author: { "@type": "Organization", name: "ThumbForge" },
          publisher: { "@type": "Organization", name: "ThumbForge", url: SITE_URL },
        }),
        jsonLd(breadcrumbSchema([{ name: "Home", path: "/" }, { name: "Blog", path: "/blog" }, { name: loaderData.title, path }])),
      ],
    };
  },
  component: PostPage,
  notFoundComponent: () => (
    <PageShell>
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="text-3xl font-bold">Post not found</h1>
        <Link to="/blog" className="mt-4 inline-block text-primary hover:underline">← Back to blog</Link>
      </div>
    </PageShell>
  ),
});

function PostPage() {
  const post = Route.useLoaderData();
  return (
    <PageShell>
      <article className="mx-auto max-w-3xl px-4 pt-14 pb-16">
        <Link to="/blog" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-4 w-4" /> Back to blog
        </Link>
        <div className="mt-6 flex items-center gap-3 text-xs text-muted-foreground">
          <span className="rounded-full glass px-2 py-0.5">{post.category}</span>
          <span>{post.date}</span>
          <span>· {post.readTime}</span>
        </div>
        <h1 className="mt-4 text-4xl font-bold md:text-5xl">
          <span className="gradient-text">{post.title}</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">{post.description}</p>

        <div className="glass mt-10 space-y-5 rounded-2xl p-6 md:p-8">
          {post.content.split("\n\n").map((block: string, i: number) => {
            if (block.startsWith("## ")) {
              return <h2 key={i} className="mt-4 text-2xl font-bold">{block.replace("## ", "")}</h2>;
            }
            if (/^\d+\. /m.test(block) || block.startsWith("- ")) {
              const items = block.split("\n").map((l: string) => l.replace(/^(\d+\.\s|-\s)/, ""));
              return (
                <ul key={i} className="list-disc space-y-1 pl-5 text-muted-foreground">
                  {items.map((it: string, j: number) => <li key={j}>{it}</li>)}
                </ul>
              );
            }
            return <p key={i} className="leading-relaxed text-muted-foreground">{block}</p>;
          })}
        </div>

        <div className="glass-strong mt-10 rounded-2xl p-6 text-center md:p-8">
          <h2 className="text-xl font-bold">Make your thumbnail now</h2>
          <p className="mt-2 text-sm text-muted-foreground">Use our free AI thumbnail generator. No sign-up, HD PNG export.</p>
          <Link to="/generator" className="mt-4 inline-flex rounded-xl btn-gradient px-5 py-2.5 text-sm font-semibold">Open the Generator</Link>
        </div>

        <div className="mt-10">
          <h2 className="text-xl font-bold">Keep reading</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {posts.filter((p) => p.slug !== post.slug).slice(0, 3).map((p) => (
              <Link key={p.slug} to="/blog/$slug" params={{ slug: p.slug }} className="glass rounded-2xl p-4 transition hover:-translate-y-1">
                <h3 className="text-sm font-semibold">{p.title}</h3>
              </Link>
            ))}
          </div>
        </div>
      </article>
    </PageShell>
  );
}
