import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { PageShell } from "@/components/site/PageShell";
import { getLanding, landings } from "@/lib/landing";
import { posts } from "@/lib/posts";
import { seo, jsonLd, faqSchema, breadcrumbSchema, SITE_URL } from "@/lib/seo";
import { ArrowRight, Check, Lightbulb } from "lucide-react";

export const Route = createFileRoute("/$slug")({
  loader: ({ params }) => {
    const page = getLanding(params.slug);
    if (!page) throw notFound();
    return page;
  },
  head: ({ loaderData }) => {
    if (!loaderData) return { meta: [{ title: "Page not found" }, { name: "robots", content: "noindex" }] };
    const path = `/${loaderData.slug}`;
    const base = seo({ title: loaderData.title, description: loaderData.description, path });
    return {
      ...base,
      scripts: [
        jsonLd(faqSchema(loaderData.faqs)),
        jsonLd(breadcrumbSchema([{ name: "Home", path: "/" }, { name: loaderData.h1, path }])),
        jsonLd({
          "@context": "https://schema.org",
          "@type": "HowTo",
          name: loaderData.h1,
          step: loaderData.steps.map((s, i) => ({ "@type": "HowToStep", position: i + 1, text: s })),
          url: `${SITE_URL}${path}`,
        }),
      ],
    };
  },
  component: LandingPage,
  notFoundComponent: () => (
    <PageShell>
      <div className="mx-auto max-w-2xl px-4 py-24 text-center">
        <h1 className="text-3xl font-bold">Page not found</h1>
        <Link to="/" className="mt-4 inline-block text-primary hover:underline">← Back to home</Link>
      </div>
    </PageShell>
  ),
});

function LandingPage() {
  const page = Route.useLoaderData();
  const related = page.related.map((s) => landings.find((l) => l.slug === s)).filter(Boolean) as typeof landings;
  const relatedPosts = posts.slice(0, 3);

  return (
    <PageShell>
      <section className="mx-auto max-w-4xl px-4 pt-16 pb-8 text-center">
        <nav aria-label="Breadcrumb" className="text-xs text-muted-foreground">
          <Link to="/" className="hover:text-foreground">Home</Link> <span>/</span> <span>{page.h1}</span>
        </nav>
        <h1 className="mt-5 text-4xl font-bold leading-tight md:text-5xl">
          <span className="gradient-text">{page.h1}</span>
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-lg text-muted-foreground">{page.intro}</p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <Link to="/generator" className="inline-flex items-center gap-2 rounded-xl btn-gradient px-6 py-3 font-semibold">
            Generate Free <ArrowRight className="h-4 w-4" />
          </Link>
          <Link to="/templates" className="inline-flex items-center gap-2 rounded-xl border border-white/20 px-6 py-3 font-semibold hover:bg-white/5">
            Browse Templates
          </Link>
        </div>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          {page.keywords.map((k) => (
            <span key={k} className="rounded-full glass px-3 py-1 text-xs text-muted-foreground">{k}</span>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-center text-2xl font-bold md:text-3xl">Why use ThumbForge</h2>
        <div className="mt-8 grid gap-5 md:grid-cols-2">
          {page.benefits.map((b) => (
            <div key={b.title} className="glass rounded-2xl p-6">
              <h3 className="flex items-center gap-2 text-lg font-semibold"><Check className="h-4 w-4 text-emerald-400" />{b.title}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{b.desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-12">
        <h2 className="text-2xl font-bold md:text-3xl">How it works</h2>
        <ol className="mt-6 space-y-3">
          {page.steps.map((s, i) => (
            <li key={i} className="glass flex gap-4 rounded-2xl p-5">
              <span className="inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg btn-gradient text-sm font-bold">{i + 1}</span>
              <p className="text-sm text-muted-foreground">{s}</p>
            </li>
          ))}
        </ol>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-12">
        <h2 className="flex items-center gap-2 text-2xl font-bold md:text-3xl"><Lightbulb className="h-6 w-6 text-yellow-400" />Pro tips</h2>
        <ul className="mt-6 list-disc space-y-2 pl-5 text-muted-foreground">
          {page.tips.map((t) => <li key={t}>{t}</li>)}
        </ul>
      </section>

      <section className="mx-auto max-w-3xl px-4 py-12">
        <h2 className="text-2xl font-bold md:text-3xl">Frequently asked questions</h2>
        <div className="mt-6 space-y-3">
          {page.faqs.map((f) => (
            <details key={f.q} className="glass rounded-2xl p-5">
              <summary className="flex cursor-pointer list-none items-center justify-between font-semibold">
                {f.q}<span className="ml-2 text-primary">+</span>
              </summary>
              <p className="mt-3 text-sm text-muted-foreground">{f.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-12">
        <h2 className="text-2xl font-bold md:text-3xl">Related tools</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {related.map((r) => (
            <Link key={r.slug} to="/$slug" params={{ slug: r.slug }} className="glass rounded-2xl p-5 transition hover:-translate-y-1 hover:bg-white/[0.08]">
              <h3 className="font-semibold">{r.h1}</h3>
              <span className="mt-3 inline-flex items-center gap-1 text-xs text-primary">Open <ArrowRight className="h-3 w-3" /></span>
            </Link>
          ))}
        </div>
        <h2 className="mt-12 text-2xl font-bold md:text-3xl">From the blog</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {relatedPosts.map((p) => (
            <Link key={p.slug} to="/blog/$slug" params={{ slug: p.slug }} className="glass rounded-2xl p-5 transition hover:-translate-y-1 hover:bg-white/[0.08]">
              <h3 className="font-semibold">{p.title}</h3>
              <p className="mt-2 text-xs text-muted-foreground">{p.description}</p>
            </Link>
          ))}
        </div>
      </section>
    </PageShell>
  );
}
