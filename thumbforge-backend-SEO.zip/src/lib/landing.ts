export type Landing = {
  slug: string;
  title: string; // <title>
  h1: string;
  description: string; // meta description
  intro: string;
  keywords: string[]; // shown as topic chips (also helps semantic relevance)
  benefits: { title: string; desc: string }[];
  steps: string[];
  tips: string[];
  faqs: { q: string; a: string }[];
  related: string[]; // slugs
};

export const landings: Landing[] = [
  {
    slug: "ai-thumbnail-generator",
    title: "AI Thumbnail Generator — Free, No Sign-up | ThumbForge",
    h1: "Free AI Thumbnail Generator for YouTube",
    description:
      "Type a prompt, pick a style and get a scroll-stopping YouTube thumbnail in seconds. Free AI thumbnail generator with HD PNG export and no sign-up.",
    intro:
      "ThumbForge is an AI thumbnail generator built for one job: turning a short idea into a clean 1280×720 YouTube thumbnail. Describe your video, choose a style and colour palette, and download the result. There is no account to create and no design experience needed.",
    keywords: ["ai thumbnail generator", "ai youtube thumbnail maker", "thumbnail generator from text", "free thumbnail ai"],
    benefits: [
      { title: "Prompt to thumbnail", desc: "Write one line about your video and the AI builds the background and layout for you." },
      { title: "Style and palette presets", desc: "Gaming, Tech, Education, Business, Vlog and more, each tuned for high contrast." },
      { title: "HD PNG export", desc: "Every thumbnail downloads at 1280×720, the size YouTube recommends." },
      { title: "Unlimited regenerations", desc: "Not happy with the first result? Regenerate as many times as you like." },
    ],
    steps: [
      "Open the generator and describe your video in a short sentence.",
      "Pick a style (for example Gaming or Tech) and a colour palette.",
      "Optionally upload your own face or product image to place on top.",
      "Click Generate, then download the HD PNG and upload it to YouTube.",
    ],
    tips: [
      "Keep the on-image text to five words or fewer so it is readable on a phone.",
      "Use one clear focal point instead of many small elements.",
      "Try two or three palettes and compare them side by side before you publish.",
    ],
    faqs: [
      { q: "Is the AI thumbnail generator really free?", a: "Yes. You can generate and download thumbnails without paying or creating an account." },
      { q: "What size are the thumbnails?", a: "1280×720 pixels in PNG, a 16:9 ratio that matches YouTube's recommended spec." },
      { q: "Can I add my own photo?", a: "Yes. Upload an image in the generator and it is placed into the thumbnail." },
    ],
    related: ["youtube-thumbnail-maker", "free-thumbnail-maker", "gaming-thumbnail-maker"],
  },
  {
    slug: "youtube-thumbnail-maker",
    title: "YouTube Thumbnail Maker Online — Free & Fast | ThumbForge",
    h1: "YouTube Thumbnail Maker (Online, Free)",
    description:
      "Make a YouTube thumbnail online in under a minute. Free YouTube thumbnail maker with AI backgrounds, ready-made styles and HD 1280×720 PNG download.",
    intro:
      "A good thumbnail is the first thing viewers judge, long before the title or the video. ThumbForge is a YouTube thumbnail maker that works in your browser: no download, no blank canvas and no learning curve. You describe the video, we handle the design.",
    keywords: ["youtube thumbnail maker", "thumbnail maker online", "make youtube thumbnail", "youtube thumbnail creator"],
    benefits: [
      { title: "Works in the browser", desc: "Nothing to install. Open the page, generate, download." },
      { title: "Made for YouTube", desc: "16:9 layout with safe margins so the duration badge does not cover your text." },
      { title: "Bold text styles", desc: "Heavy display fonts with strong outlines that stay readable at small sizes." },
      { title: "Fast iteration", desc: "Test several versions of one video and keep the one that looks strongest." },
    ],
    steps: [
      "Go to the generator and write what your video is about.",
      "Select the YouTube style, or one that matches your niche.",
      "Generate and review. Change the palette or prompt and try again if needed.",
      "Download the PNG and set it as your custom thumbnail in YouTube Studio.",
    ],
    tips: [
      "Leave the bottom-right corner free, YouTube places the video length there.",
      "Use contrasting colours between text and background.",
      "Check the thumbnail at small size before uploading, since most views happen on mobile.",
    ],
    faqs: [
      { q: "What is the best YouTube thumbnail size?", a: "1280×720 pixels with a 16:9 aspect ratio, under 2 MB, in JPG, PNG, GIF or WEBP." },
      { q: "Do I need design skills?", a: "No. Pick a style and a palette and the generator does the layout." },
      { q: "Is there a watermark?", a: "ThumbForge exports clean PNG files for your own videos." },
    ],
    related: ["ai-thumbnail-generator", "youtube-thumbnail-templates", "thumbnail-maker-for-shorts"],
  },
  {
    slug: "free-thumbnail-maker",
    title: "Free Thumbnail Maker — No Sign-up, No Watermark | ThumbForge",
    h1: "Free Thumbnail Maker With No Sign-up",
    description:
      "A truly free thumbnail maker: no account, no credit card, HD PNG export. Create unlimited YouTube thumbnails with AI on ThumbForge.",
    intro:
      "Many thumbnail tools lock downloads behind an account or a paid plan. ThumbForge keeps it simple: open the page, create your thumbnail and download it. If you are a new creator watching every dollar, a free thumbnail maker that does not get in your way matters.",
    keywords: ["free thumbnail maker", "thumbnail maker no sign up", "thumbnail maker without watermark", "unlimited thumbnail generator"],
    benefits: [
      { title: "No account needed", desc: "Start generating immediately, with no email or password." },
      { title: "No credit card", desc: "Nothing to cancel and no trial that expires." },
      { title: "Unlimited use", desc: "Make as many thumbnails as your channel needs." },
      { title: "Commercial use", desc: "Use your thumbnails on your channel, in ads and for clients." },
    ],
    steps: [
      "Open the generator, no login screen appears.",
      "Describe your video and choose a style.",
      "Generate and download the HD PNG.",
    ],
    tips: [
      "Save your best-performing thumbnails and reuse the same palette to build a recognisable channel look.",
      "Use the free regenerations to A/B test two options before you publish.",
    ],
    faqs: [
      { q: "Is ThumbForge free forever?", a: "You can currently generate and download thumbnails for free with no account." },
      { q: "Are there limits per day?", a: "There is no daily cap on regenerating or downloading thumbnails." },
      { q: "Do you store my images?", a: "Compositing runs in your browser. See our privacy policy for details." },
    ],
    related: ["ai-thumbnail-generator", "youtube-thumbnail-maker", "clickbait-thumbnail-generator"],
  },
  {
    slug: "gaming-thumbnail-maker",
    title: "Gaming Thumbnail Maker — Free YouTube Gaming Thumbnails | ThumbForge",
    h1: "Gaming Thumbnail Maker for YouTube",
    description:
      "Create high-energy gaming thumbnails for Minecraft, Roblox, Fortnite and more. Free gaming thumbnail maker with neon palettes and bold text.",
    intro:
      "Gaming is the most crowded niche on YouTube, so your thumbnail has to pop instantly. ThumbForge includes a Gaming style with saturated palettes, strong contrast and punchy text built for clips, montages, tutorials and live-stream highlights.",
    keywords: ["gaming thumbnail maker", "youtube gaming thumbnail", "minecraft thumbnail maker", "roblox thumbnail maker", "fortnite thumbnail maker"],
    benefits: [
      { title: "Neon and high-contrast palettes", desc: "Purple Blast and Neon Cyber are popular choices for gaming content." },
      { title: "Reaction-face friendly", desc: "Upload a face or screenshot and place it as the focal point." },
      { title: "Short punchy text", desc: "Phrases like INSANE CLUTCH or 1v5 work well when kept to a few words." },
      { title: "Works for any game", desc: "Use it for Minecraft, Roblox, Fortnite, Valorant, GTA and indie games." },
    ],
    steps: [
      "Type a prompt such as 'insane 1v5 clutch in Valorant'.",
      "Choose the Gaming style and a neon palette.",
      "Upload a gameplay screenshot or your reaction face if you have one.",
      "Generate, download and upload to YouTube Studio.",
    ],
    tips: [
      "Show the moment of peak action, not the menu screen.",
      "Zoom in on faces and key objects, small details disappear on mobile.",
      "Use a consistent colour scheme across a series so viewers recognise it.",
    ],
    faqs: [
      { q: "Can I make Minecraft or Roblox thumbnails?", a: "Yes. Describe the game and the moment, then upload a screenshot if you want to feature it." },
      { q: "What text works best on gaming thumbnails?", a: "Two to four words that create curiosity or show stakes, for example 'NEW META BROKEN'." },
      { q: "Is it free?", a: "Yes, no sign-up and no watermark." },
    ],
    related: ["youtube-thumbnail-templates", "clickbait-thumbnail-generator", "ai-thumbnail-generator"],
  },
  {
    slug: "youtube-thumbnail-templates",
    title: "Free YouTube Thumbnail Templates — Gaming, Vlog, Tech | ThumbForge",
    h1: "Free YouTube Thumbnail Templates",
    description:
      "Browse free YouTube thumbnail templates for gaming, vlog, tech review, education, business and more, then customise them with AI in seconds.",
    intro:
      "Templates give you a proven starting point instead of a blank canvas. ThumbForge offers category-based thumbnail templates and style presets that you can adapt to your own video with a single prompt.",
    keywords: ["youtube thumbnail templates", "gaming thumbnail templates", "vlog thumbnail templates", "tech review thumbnail templates", "podcast thumbnail templates"],
    benefits: [
      { title: "Niche-based categories", desc: "Gaming, Education, Tech, Business, News, Travel, Food and Finance." },
      { title: "Sample headlines included", desc: "See text examples that fit each niche and adapt them to your topic." },
      { title: "One-click customising", desc: "Open the generator, enter your topic and the style is applied." },
      { title: "Consistent branding", desc: "Reuse the same style across videos to build a recognisable look." },
    ],
    steps: [
      "Open the Templates page and choose the category closest to your niche.",
      "Pick a sample layout you like.",
      "Go to the generator and describe your own video.",
      "Download your customised thumbnail.",
    ],
    tips: [
      "Start from a template, then change the colours to match your channel branding.",
      "Keep headline length similar to the sample, short text reads better.",
    ],
    faqs: [
      { q: "Are the templates free?", a: "Yes, all templates and styles are free to use." },
      { q: "Can I use templates for podcasts or vlogs?", a: "Yes. Use the Vlog or YouTube style and adjust the prompt and palette." },
    ],
    related: ["gaming-thumbnail-maker", "youtube-thumbnail-maker", "ai-thumbnail-generator"],
  },
  {
    slug: "thumbnail-maker-for-shorts",
    title: "Thumbnail Maker for YouTube Shorts & Cover Images | ThumbForge",
    h1: "Thumbnail Maker for Shorts, Reels and Cover Images",
    description:
      "Make eye-catching cover images for YouTube Shorts and short-form video. Generate bold 16:9 thumbnails with AI and reuse them across platforms.",
    intro:
      "Short-form video lives on the feed, but your channel page, playlists, search results and embedded links still show a custom image. ThumbForge makes bold 16:9 graphics that work well as channel-page covers, playlist art and link previews, and you can crop them for vertical formats in any editor.",
    keywords: ["thumbnail generator for shorts", "youtube shorts cover", "short video cover maker", "reels cover image"],
    benefits: [
      { title: "Bold at small sizes", desc: "Large text and clear subjects stay legible in tiny previews." },
      { title: "Reusable artwork", desc: "Use the same design for playlists, community posts and link cards." },
      { title: "Fast batch work", desc: "Generate several variations quickly when you publish often." },
    ],
    steps: [
      "Describe the topic of your short.",
      "Generate a 1280×720 graphic using the Vlog or YouTube style.",
      "Download it and crop it to 9:16 in your editor if you need a vertical version.",
    ],
    tips: [
      "Keep important content in the centre so it survives cropping.",
      "Use one large word or number instead of a sentence.",
    ],
    faqs: [
      { q: "Does ThumbForge export vertical 9:16 images?", a: "Exports are 1280×720 (16:9). You can crop the result to vertical in any image editor." },
      { q: "Can I use the same image on other platforms?", a: "Yes, thumbnails you generate can be used on any platform." },
    ],
    related: ["youtube-thumbnail-maker", "free-thumbnail-maker", "ai-thumbnail-generator"],
  },
  {
    slug: "clickbait-thumbnail-generator",
    title: "High-CTR Thumbnail Generator — Click-Worthy Thumbnails | ThumbForge",
    h1: "High-CTR Thumbnail Generator (Click-Worthy, Not Spammy)",
    description:
      "Generate attention-grabbing YouTube thumbnails that raise click-through rate: bold text, strong contrast and clear focal points. Free with ThumbForge.",
    intro:
      "Thumbnails that earn clicks share a few traits: one clear subject, strong contrast, short text and an emotional hook. ThumbForge bakes these patterns into its styles so you can create attention-grabbing thumbnails quickly. Just make sure the thumbnail honestly represents your video, because misleading images hurt watch time.",
    keywords: ["clickbait thumbnail generator", "high ctr thumbnail", "increase youtube ctr", "attention grabbing thumbnail"],
    benefits: [
      { title: "Curiosity-driven layouts", desc: "Badges such as MUST WATCH and bold headlines create a reason to click." },
      { title: "High contrast by default", desc: "Palettes are chosen to stand out in a busy feed." },
      { title: "Easy A/B variations", desc: "Generate several versions and test them with YouTube's thumbnail testing." },
    ],
    steps: [
      "Write the single most interesting promise of your video.",
      "Choose a bold palette and generate.",
      "Compare variations, keep the clearest, and match it to your title.",
    ],
    tips: [
      "Make the thumbnail and title complement each other, not repeat each other.",
      "Never promise something the video does not deliver.",
    ],
    faqs: [
      { q: "Will a bold thumbnail raise my CTR?", a: "Often, but results depend on your audience and topic. Test variations to learn what works for your channel." },
      { q: "Is misleading clickbait a good idea?", a: "No. Honest, curiosity-driven thumbnails perform better over time because viewers stay and watch." },
    ],
    related: ["gaming-thumbnail-maker", "ai-thumbnail-generator", "free-thumbnail-maker"],
  },
  {
    slug: "tech-review-thumbnail-maker",
    title: "Tech Review Thumbnail Maker — Clean Product Thumbnails | ThumbForge",
    h1: "Tech Review Thumbnail Maker",
    description:
      "Create sleek thumbnails for tech reviews, unboxings and tutorials. Free tech thumbnail maker with cyan and purple palettes and HD export.",
    intro:
      "Tech audiences expect clean, modern visuals. The Tech style on ThumbForge uses cool gradients, crisp type and plenty of space for a product shot, ideal for reviews, comparisons, unboxings, leaks and how-to videos.",
    keywords: ["tech review thumbnail", "unboxing thumbnail maker", "gadget review thumbnail", "tech youtube thumbnail"],
    benefits: [
      { title: "Product-focused layouts", desc: "Upload a product photo and keep the background simple." },
      { title: "Cool, modern palettes", desc: "Neon Cyber and Ocean suit hardware and software topics." },
      { title: "Clear comparison text", desc: "Short headlines such as 'iPHONE vs PIXEL' fit nicely." },
    ],
    steps: [
      "Describe the product and angle, for example 'M-series laptop honest review'.",
      "Select the Tech style and a cool palette.",
      "Upload a product image, generate and download.",
    ],
    tips: [
      "Use a transparent-background product photo for the cleanest look.",
      "Put the product name or a verdict word in large type.",
    ],
    faqs: [
      { q: "Can I add a product photo?", a: "Yes. Upload it in the generator and it is composited into the thumbnail." },
      { q: "Is it good for unboxing videos?", a: "Yes. Use short text like 'UNBOXING' or the product name and a bright accent colour." },
    ],
    related: ["youtube-thumbnail-templates", "ai-thumbnail-generator", "youtube-thumbnail-maker"],
  },
  {
    slug: "vlog-thumbnail-maker",
    title: "Vlog Thumbnail Maker — Free Lifestyle & Travel Thumbnails | ThumbForge",
    h1: "Vlog Thumbnail Maker",
    description:
      "Make warm, personal vlog thumbnails for lifestyle, travel and daily-life videos. Free vlog thumbnail maker with HD export and no sign-up.",
    intro:
      "Vlog thumbnails work best when they feel human: a real face, a clear emotion and a simple message. The Vlog style on ThumbForge uses warm gradients and friendly type so your personality comes through.",
    keywords: ["vlog thumbnail maker", "travel vlog thumbnail", "lifestyle thumbnail", "daily vlog thumbnail ideas"],
    benefits: [
      { title: "Face-forward layouts", desc: "Upload a photo of yourself and make it the hero of the image." },
      { title: "Warm palettes", desc: "Sunset and Emerald give a natural, inviting feel." },
      { title: "Story-first text", desc: "Short lines such as '24 HOURS IN TOKYO' set expectations quickly." },
    ],
    steps: [
      "Write a one-line summary of the vlog.",
      "Choose the Vlog style and a warm palette.",
      "Upload your best expressive photo, generate and download.",
    ],
    tips: [
      "Choose a photo with a clear emotion, surprise or joy performs well.",
      "Include a place name or number to make the story concrete.",
    ],
    faqs: [
      { q: "Do I need a professional photo?", a: "No. A clear, well-lit phone photo is enough." },
      { q: "Can I make travel thumbnails?", a: "Yes. Describe the destination and use a Sunset or Ocean palette." },
    ],
    related: ["youtube-thumbnail-templates", "free-thumbnail-maker", "youtube-thumbnail-maker"],
  },
];

export function getLanding(slug: string) {
  return landings.find((l) => l.slug === slug);
}
