# SEO changes (ThumbForge)

- `src/lib/seo.ts` – helper for title/description/canonical/OG/Twitter + JSON-LD (FAQ, Breadcrumb)
- `src/lib/landing.ts` + `src/routes/$slug.tsx` – 8 keyword landing pages at root URLs
  (/ai-thumbnail-generator, /youtube-thumbnail-maker, /free-thumbnail-maker, /gaming-thumbnail-maker,
  /youtube-thumbnail-templates, /thumbnail-maker-for-shorts, /clickbait-thumbnail-generator,
  /tech-review-thumbnail-maker, /vlog-thumbnail-maker). Add more by appending to `landings`.
- `src/lib/posts.ts` – 6 new blog posts (add more the same way)
- Every route now has unique title, description, canonical, OG/Twitter tags
- Root: Organization + WebSite + SoftwareApplication schema; Home H1 now has the keyword
- Sitemap fixed (was missing the domain); now includes landing pages, posts
- robots.txt has Sitemap line and blocks /api/
- Fixed: /blog/<slug> never rendered (parent route had no Outlet).
  blog.tsx is now a layout, list moved to blog.index.tsx
- public/og-image.png added (1200x630 social preview)
